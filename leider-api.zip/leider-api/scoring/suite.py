def score_suite(eci: float, cci: float) -> dict:
    ets = max(0, min(100, (cci * 0.65) + ((100 - eci) * 0.35)))
    ets2 = max(0, min(100, (cci * 0.5) + ((100 - eci) * 0.5)))
    eis = max(0, min(100, (eci * 0.6) + ((100 - cci) * 0.4)))
    eti = max(0, min(100, (cci * 0.7) + ((100 - eci) * 0.3)))

    return {
        "ets": round(ets, 2),
        "ets2": round(ets2, 2),
        "eis": round(eis, 2),
        "eti": round(eti, 2),
    }
