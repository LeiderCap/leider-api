def structural_equity_map(eci: float, cci: float) -> dict:
    x = round(eci, 2)
    y = round(cci, 2)

    if eci >= 60 and cci >= 60:
        quadrant = "Convertible but Fragile"
    elif eci >= 60 and cci < 60:
        quadrant = "Structurally Compounding"
    elif eci < 60 and cci >= 60:
        quadrant = "Value Leakage System"
    else:
        quadrant = "Structurally Constrained"

    return {"x": x, "y": y, "quadrant": quadrant}
