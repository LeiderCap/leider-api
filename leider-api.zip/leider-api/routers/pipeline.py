from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import get_db
from models import Deal
from schemas import DealCreate, DealStageUpdate, DealOwnerUpdate, DealActionUpdate, DealAlertCreate

router = APIRouter()


@router.get("")
async def list_pipeline(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Deal).order_by(Deal.updated_at.desc()))
    return result.scalars().all()


@router.post("")
async def create_deal(payload: DealCreate, db: AsyncSession = Depends(get_db)):
    ticker = payload.ticker.upper()
    existing = await db.execute(select(Deal).where(Deal.ticker == ticker))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Deal already exists")

    row = Deal(
        ticker=ticker,
        stage=payload.stage,
        priority=payload.priority,
        pod_owner=payload.pod_owner,
        next_action=payload.next_action,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return row


@router.get("/{ticker}")
async def get_deal(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(select(Deal).where(Deal.ticker == ticker))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Deal not found")
    return row


@router.put("/{ticker}/stage")
async def update_stage(ticker: str, payload: DealStageUpdate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(select(Deal).where(Deal.ticker == ticker))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Deal not found")

    row.stage = payload.stage
    row.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(row)
    return row


@router.put("/{ticker}/owner")
async def update_owner(ticker: str, payload: DealOwnerUpdate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(select(Deal).where(Deal.ticker == ticker))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Deal not found")

    row.pod_owner = payload.pod_owner
    row.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(row)
    return row


@router.put("/{ticker}/action")
async def update_action(ticker: str, payload: DealActionUpdate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(select(Deal).where(Deal.ticker == ticker))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Deal not found")

    row.next_action = payload.next_action
    row.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(row)
    return row


@router.post("/{ticker}/alert")
async def create_alert(ticker: str, payload: DealAlertCreate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(select(Deal).where(Deal.ticker == ticker))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Deal not found")

    existing = row.alert_flags or ""
    row.alert_flags = f"{existing}\n{payload.alert}".strip()
    row.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(row)
    return row


@router.get("/alerts")
async def get_alerts(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Deal).where(Deal.alert_flags.is_not(None)))
    rows = result.scalars().all()
    return [{"ticker": r.ticker, "alerts": r.alert_flags} for r in rows if r.alert_flags]


@router.get("/stage/{stage}")
async def get_by_stage(stage: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Deal).where(Deal.stage == stage))
    return result.scalars().all()
