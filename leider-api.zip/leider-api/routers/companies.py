from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import Company, LensScore
from schemas import CompanyCreate, CompanyUpdate

router = APIRouter()


@router.post("")
async def create_company(payload: CompanyCreate, db: AsyncSession = Depends(get_db)):
    ticker = payload.ticker.upper().strip()

    existing = await db.get(Company, ticker)
    if existing:
        raise HTTPException(status_code=400, detail=f"{ticker} already exists")

    company = Company(
        ticker=ticker,
        name=payload.name,
        sector=payload.sector,
        exchange=payload.exchange,
        market_cap=payload.market_cap,
        shares_out=payload.shares_out,
        float_shares=payload.float_shares,
        net_debt=payload.net_debt,
        ev=payload.ev,
        notes=payload.notes,
    )
    db.add(company)
    await db.commit()
    await db.refresh(company)
    return {"status": "created", "ticker": company.ticker}


@router.get("")
async def list_companies(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Company).order_by(Company.ticker))
    rows = result.scalars().all()
    return rows


@router.get("/{ticker}")
async def get_company(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    company = await db.get(Company, ticker)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    score_result = await db.execute(
        select(LensScore)
        .where(LensScore.ticker == ticker)
        .order_by(desc(LensScore.scored_at))
        .limit(1)
    )
    latest_score = score_result.scalar_one_or_none()

    return {"company": company, "latest_score": latest_score}


@router.put("/{ticker}")
async def update_company(ticker: str, payload: CompanyUpdate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    company = await db.get(Company, ticker)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(company, field, value)

    await db.commit()
    await db.refresh(company)
    return {"status": "updated", "ticker": company.ticker}


@router.delete("/{ticker}")
async def delete_company(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    company = await db.get(Company, ticker)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    await db.delete(company)
    await db.commit()
    return {"status": "deleted", "ticker": ticker}
