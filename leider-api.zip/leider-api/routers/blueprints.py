from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import Blueprint, LensScore
from schemas import BlueprintCreate, BlueprintUpdate

router = APIRouter()


@router.post("/{ticker}")
async def generate_blueprint(ticker: str, payload: BlueprintCreate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()

    score_result = await db.execute(
        select(LensScore)
        .where(LensScore.ticker == ticker)
        .order_by(desc(LensScore.scored_at))
        .limit(1)
    )
    score = score_result.scalar_one_or_none()
    if not score:
        raise HTTPException(status_code=404, detail="Run scoring first")

    version_result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
        .limit(1)
    )
    latest = version_result.scalar_one_or_none()
    next_version = 1 if not latest else latest.version + 1

    bp = Blueprint(
        ticker=ticker,
        anchor=payload.anchor or f"Anchor based on quadrant: {score.quadrant}",
        core_problem=payload.core_problem or f"CCI={score.cci}, ECI={score.eci}, ETI={score.eti}",
        era_stack=payload.era_stack or "Initial ERA stack placeholder",
        capital_plan=payload.capital_plan or "Capital plan placeholder",
        key_actions=payload.key_actions or "Generate intervention sequence",
        timeline=payload.timeline or "12-month MVP timeline",
        version=next_version,
    )
    db.add(bp)
    await db.commit()
    await db.refresh(bp)
    return bp


@router.get("/{ticker}")
async def get_latest_blueprint(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Blueprint not found")
    return row


@router.get("/{ticker}/all")
async def get_all_blueprints(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
    )
    return result.scalars().all()


@router.put("/{ticker}")
async def update_latest_blueprint(ticker: str, payload: BlueprintUpdate, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Blueprint not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(row, field, value)

    await db.commit()
    await db.refresh(row)
    return row


@router.post("/{ticker}/approve")
async def approve_blueprint(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Blueprint not found")

    row.approved = True
    await db.commit()
    await db.refresh(row)
    return row


@router.get("/{ticker}/export")
async def export_blueprint(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Blueprint)
        .where(Blueprint.ticker == ticker)
        .order_by(desc(Blueprint.version))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Blueprint not found")

    return {
        "ticker": row.ticker,
        "version": row.version,
        "approved": row.approved,
        "pdf_ready": True,
        "content": {
            "anchor": row.anchor,
            "core_problem": row.core_problem,
            "era_stack": row.era_stack,
            "capital_plan": row.capital_plan,
            "key_actions": row.key_actions,
            "timeline": row.timeline,
        },
    }
