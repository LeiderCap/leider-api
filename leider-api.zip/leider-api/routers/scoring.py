import json
import yfinance as yf
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import Company, LensScore
from scoring.cci import score_cci
from scoring.eci import score_eci
from scoring.suite import score_suite
from scoring.map import structural_equity_map

router = APIRouter()


def safe_num(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def fetch_market_snapshot(ticker: str) -> dict:
    info = yf.Ticker(ticker).info

    market_cap = safe_num(info.get("marketCap"))
    enterprise_value = safe_num(info.get("enterpriseValue"), market_cap)
    total_debt = safe_num(info.get("totalDebt"))
    shares_out = safe_num(info.get("sharesOutstanding"), 1)
    float_shares = safe_num(info.get("floatShares"), 0)
    ebitda = safe_num(info.get("ebitda"), 1)
    gross_margin = safe_num(info.get("grossMargins"), 0) * 100
    revenue_growth = safe_num(info.get("revenueGrowth"), 0) * 100
    insider_pct = safe_num(info.get("heldPercentInsiders"), 0) * 100
    institutional_pct = safe_num(info.get("heldPercentInstitutions"), 0) * 100

    ev_to_mktcap = enterprise_value / max(market_cap, 1)
    leverage_ratio = total_debt / max(ebitda, 1)
    float_pct = (float_shares / max(shares_out, 1)) * 100 if shares_out else 0

    return {
        "market_cap": market_cap,
        "enterprise_value": enterprise_value,
        "total_debt": total_debt,
        "shares_out": shares_out,
        "float_shares": float_shares,
        "ebitda": ebitda,
        "gross_margin": gross_margin,
        "revenue_growth": revenue_growth,
        "insider_pct": insider_pct,
        "institutional_pct": institutional_pct,
        "ev_to_mktcap": ev_to_mktcap,
        "leverage_ratio": leverage_ratio,
        "float_pct": float_pct,
    }


async def persist_company_snapshot(ticker: str, snap: dict, db: AsyncSession):
    company = await db.get(Company, ticker)
    if not company:
        company = Company(ticker=ticker, name=ticker)
        db.add(company)

    company.market_cap = snap["market_cap"]
    company.shares_out = snap["shares_out"]
    company.float_shares = snap["float_shares"]
    company.net_debt = snap["total_debt"]
    company.ev = snap["enterprise_value"]


@router.post("/{ticker}")
async def run_full_diagnostic(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()

    try:
        snap = fetch_market_snapshot(ticker)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not fetch market data for {ticker}: {str(e)}")

    cci = score_cci(
        voting_pct_insider=snap["insider_pct"],
        dual_class=False,
        float_pct=snap["float_pct"],
        ev_to_mktcap=snap["ev_to_mktcap"],
        net_debt_to_ebitda=snap["leverage_ratio"],
        sector_stigma=50,
        multiple_gap=20,
    )

    eci = score_eci(
        gross_margin=snap["gross_margin"],
        ebitda_margin=20,
        revenue_growth=snap["revenue_growth"],
        insider_ownership_pct=snap["insider_pct"],
        institutional_ownership_pct=snap["institutional_pct"],
        dilution_3y_pct=15,
        leverage_ratio=snap["leverage_ratio"],
    )

    suite = score_suite(eci=eci["eci"], cci=cci["cci"])
    map_result = structural_equity_map(eci=eci["eci"], cci=cci["cci"])

    await persist_company_snapshot(ticker, snap, db)

    row = LensScore(
        ticker=ticker,
        eci=eci["eci"],
        eds=eci["eds"],
        csis=eci["csis"],
        giis=eci["giis"],
        lpss=eci["lpss"],
        res=eci["res"],
        cci=cci["cci"],
        ccs=cci["ccs"],
        fds=cci["fds"],
        eei=cci["eei"],
        nds=cci["nds"],
        ets=suite["ets"],
        ets2=suite["ets2"],
        eis=suite["eis"],
        eti=suite["eti"],
        band=cci["band"],
        quadrant=map_result["quadrant"],
        map_x=map_result["x"],
        map_y=map_result["y"],
        payload_json=json.dumps({
            "snapshot": snap,
            "eci": eci,
            "cci": cci,
            "suite": suite,
            "map": map_result,
        }),
    )

    db.add(row)
    await db.commit()
    await db.refresh(row)

    return {
        "ticker": ticker,
        "eci": row.eci,
        "cci": row.cci,
        "ets": row.ets,
        "ets2": row.ets2,
        "eis": row.eis,
        "eti": row.eti,
        "band": row.band,
        "quadrant": row.quadrant,
        "map_x": row.map_x,
        "map_y": row.map_y,
        "scored_at": row.scored_at,
        "details": json.loads(row.payload_json),
    }


@router.post("/{ticker}/eci")
async def run_eci_only(ticker: str):
    ticker = ticker.upper()
    snap = fetch_market_snapshot(ticker)
    return score_eci(
        gross_margin=snap["gross_margin"],
        ebitda_margin=20,
        revenue_growth=snap["revenue_growth"],
        insider_ownership_pct=snap["insider_pct"],
        institutional_ownership_pct=snap["institutional_pct"],
        dilution_3y_pct=15,
        leverage_ratio=snap["leverage_ratio"],
    )


@router.post("/{ticker}/cci")
async def run_cci_only(ticker: str):
    ticker = ticker.upper()
    snap = fetch_market_snapshot(ticker)
    return score_cci(
        voting_pct_insider=snap["insider_pct"],
        dual_class=False,
        float_pct=snap["float_pct"],
        ev_to_mktcap=snap["ev_to_mktcap"],
        net_debt_to_ebitda=snap["leverage_ratio"],
        sector_stigma=50,
        multiple_gap=20,
    )


@router.post("/{ticker}/suite")
async def run_suite_only(ticker: str):
    ticker = ticker.upper()
    snap = fetch_market_snapshot(ticker)
    cci = score_cci(
        voting_pct_insider=snap["insider_pct"],
        dual_class=False,
        float_pct=snap["float_pct"],
        ev_to_mktcap=snap["ev_to_mktcap"],
        net_debt_to_ebitda=snap["leverage_ratio"],
        sector_stigma=50,
        multiple_gap=20,
    )
    eci = score_eci(
        gross_margin=snap["gross_margin"],
        ebitda_margin=20,
        revenue_growth=snap["revenue_growth"],
        insider_ownership_pct=snap["insider_pct"],
        institutional_ownership_pct=snap["institutional_pct"],
        dilution_3y_pct=15,
        leverage_ratio=snap["leverage_ratio"],
    )
    return score_suite(eci=eci["eci"], cci=cci["cci"])


@router.post("/{ticker}/eti")
async def run_eti_only(ticker: str):
    ticker = ticker.upper()
    snap = fetch_market_snapshot(ticker)
    cci = score_cci(
        voting_pct_insider=snap["insider_pct"],
        dual_class=False,
        float_pct=snap["float_pct"],
        ev_to_mktcap=snap["ev_to_mktcap"],
        net_debt_to_ebitda=snap["leverage_ratio"],
        sector_stigma=50,
        multiple_gap=20,
    )
    eci = score_eci(
        gross_margin=snap["gross_margin"],
        ebitda_margin=20,
        revenue_growth=snap["revenue_growth"],
        insider_ownership_pct=snap["insider_pct"],
        institutional_ownership_pct=snap["institutional_pct"],
        dilution_3y_pct=15,
        leverage_ratio=snap["leverage_ratio"],
    )
    return {"ticker": ticker, "eti": score_suite(eci=eci["eci"], cci=cci["cci"])["eti"]}


@router.get("/{ticker}")
async def get_latest_score(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(LensScore)
        .where(LensScore.ticker == ticker)
        .order_by(desc(LensScore.scored_at))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="No score found")
    return row


@router.get("/{ticker}/history")
async def get_score_history(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(LensScore)
        .where(LensScore.ticker == ticker)
        .order_by(desc(LensScore.scored_at))
    )
    return result.scalars().all()


@router.get("/{ticker}/map")
async def get_score_map(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(LensScore)
        .where(LensScore.ticker == ticker)
        .order_by(desc(LensScore.scored_at))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="No score found")
    return {"ticker": ticker, "x": row.map_x, "y": row.map_y, "quadrant": row.quadrant}
