from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import get_db
from models import Signal
from schemas import SignalCreate

router = APIRouter()


@router.get("")
async def list_signals(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Signal).order_by(Signal.created_at.desc()))
    return result.scalars().all()


@router.get("/{ticker}")
async def get_signals_for_ticker(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    result = await db.execute(
        select(Signal)
        .where(Signal.ticker == ticker)
        .order_by(Signal.created_at.desc())
    )
    return result.scalars().all()


@router.post("/{ticker}")
async def create_signal(ticker: str, payload: SignalCreate, db: AsyncSession = Depends(get_db)):
    row = Signal(
        ticker=ticker.upper(),
        signal_type=payload.signal_type,
        title=payload.title,
        description=payload.description,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return row


@router.get("/type/{signal_type}")
async def get_signals_by_type(signal_type: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Signal)
        .where(Signal.signal_type == signal_type)
        .order_by(Signal.created_at.desc())
    )
    return result.scalars().all()
