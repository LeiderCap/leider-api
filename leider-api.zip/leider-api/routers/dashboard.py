from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from database import get_db
from models import Deal, Blueprint, LensScore

router = APIRouter()


@router.get("")
async def get_dashboard(db: AsyncSession = Depends(get_db)):
    active_deals = await db.scalar(select(func.count()).select_from(Deal))
    blueprints = await db.scalar(select(func.count()).select_from(Blueprint))
    scores = await db.scalar(select(func.count()).select_from(LensScore))

    return {
        "active_deals": active_deals or 0,
        "blueprints": blueprints or 0,
        "score_records": scores or 0,
        "capital_unlocked": None,
        "completions": 0,
        "delta_ev": None,
    }


@router.get("/pipeline")
async def get_pipeline_distribution(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Deal.stage, func.count())
        .group_by(Deal.stage)
    )
    return [{"stage": stage, "count": count} for stage, count in result.all()]


@router.get("/flywheel")
async def get_flywheel(db: AsyncSession = Depends(get_db)):
    return {
        "inbound_deals": 0,
        "lp_capital": 0,
        "pattern_accuracy": None,
    }
