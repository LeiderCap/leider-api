import yfinance as yf
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_db
from models import Company, Form25Queue
from schemas import Form25Create, Form25Classify

router = APIRouter()


def safe_num(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


@router.post("/{ticker}/yfinance")
async def ingest_yfinance(ticker: str, db: AsyncSession = Depends(get_db)):
    ticker = ticker.upper()
    try:
        info = yf.Ticker(ticker).info
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not pull yfinance data: {str(e)}")

    company = await db.get(Company, ticker)
    if not company:
        company = Company(ticker=ticker, name=info.get("shortName") or ticker)
        db.add(company)

    company.name = info.get("shortName") or company.name
    company.sector = info.get("sector") or company.sector
    company.exchange = info.get("exchange") or company.exchange
    company.market_cap = safe_num(info.get("marketCap"))
    company.shares_out = safe_num(info.get("sharesOutstanding"))
    company.float_shares = safe_num(info.get("floatShares"))
    company.net_debt = safe_num(info.get("totalDebt"))
    company.ev = safe_num(info.get("enterpriseValue"))

    await db.commit()
    await db.refresh(company)

    return {"status": "ingested", "ticker": ticker, "company": company}


@router.post("/{ticker}/edgar")
async def ingest_edgar(ticker: str):
    return {
        "ticker": ticker.upper(),
        "status": "stub",
        "message": "EDGAR ingestion scaffolded; implement SEC fetch next.",
    }


@router.post("/form25")
async def ingest_form25(payload: Form25Create, db: AsyncSession = Depends(get_db)):
    row = Form25Queue(
        ticker=(payload.ticker.upper() if payload.ticker else None),
        filing_url=payload.filing_url,
        notes=payload.notes,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return row


@router.get("/form25/queue")
async def get_form25_queue(db: AsyncSession = Depends(get_db)):
    from sqlalchemy import select
    result = await db.execute(select(Form25Queue).order_by(Form25Queue.created_at.desc()))
    return result.scalars().all()


@router.put("/form25/{item_id}/classify")
async def classify_form25(item_id: int, payload: Form25Classify, db: AsyncSession = Depends(get_db)):
    row = await db.get(Form25Queue, item_id)
    if not row:
        raise HTTPException(status_code=404, detail="Queue item not found")

    row.classification = payload.classification
    row.notes = payload.notes or row.notes
    await db.commit()
    await db.refresh(row)
    return row
